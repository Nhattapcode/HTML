document.addEventListener("DOMContentLoaded", async function () {
    const urlParams = new URLSearchParams(window.location.search);
    const dataIndex = urlParams.get('index');

    const response = await fetch("movies.json"); // Đường dẫn đúng đến tệp JSON
    const data = await response.json();
    const movieData = data[dataIndex]; // Lấy dữ liệu phim tương ứng

    const movieTitle = document.getElementById("movieTitle");
    const movieState = document.getElementById("movieState");
    const movieDescription = document.getElementById("movieDescription");
    const movieGerne = document.getElementById("movieGerne");
    const movieActor = document.getElementById("movieActor");
    const movieDirector = document.getElementById("movieDirector");
    const movieNation = document.getElementById("movieNation");
    const movieReleaseYear = document.getElementById("movieReleaseYear");
    const movieProducer = document.getElementById("movieProducer");
    const movieIbmrate = document.getElementById("movieIbmrate");

    movieTitle.textContent = movieData.title;
    movieState.textContent = "Trạng thái: " + movieData.state;
    movieDescription.textContent = movieData.description;
    movieGerne.textContent = "Thể loại: " + movieData.gerne;
    movieActor.textContent = "Diễn viên: " + movieData.actor;
    movieDirector.textContent = "Đạo diễn: " + movieData.director;
    movieNation.textContent = "Quốc gia: " + movieData.nation;
    movieReleaseYear.textContent = "Năm: " + movieData.releaseYear;
    movieProducer.textContent = "Sản xuất: " + movieData.producer;
    movieIbmrate.textContent = "Điểm IBM: " + movieData.ibmrate;

    // Hiển thị chi tiết phim
    const movieDetail = document.querySelector(".movie-detail");
    movieDetail.style.display = "block";
});

// Xử lý sự kiện khi nhấp vào nút "Play"
function playMovie(dataIndex) {
    // Thực hiện hành động khi nhấn nút "Play Phim"
    // Ví dụ: Chuyển đến trang phát phim
    window.location.href = 'watch-movie.html?index=' + dataIndex;
}

// Xử lý sự kiện khi nhấp vào nút "Trailer"
function openTrailer(videoLink) {
    // Thực hiện hành động khi nhấn nút "Xem Trailer"
    // Ví dụ: Mở video trailer trong cửa sổ mới
    window.open('https://www.youtube.com/watch?v=' + videoLink);
}

// Đặt các sự kiện cho nút "Play" và "Trailer"
const playButton = document.querySelector(".play-button");
const trailerButton = document.querySelector(".trailer-button");

playButton.addEventListener("click", function() {
    playMovie(dataIndex);
});

trailerButton.addEventListener("click", function() {
    openTrailer(movieData.trailerLink);
});

// Scroll về đầu trang
function goToTop() {
    window.scrollTo({ top: 0, behavior: 'smooth' });
}
